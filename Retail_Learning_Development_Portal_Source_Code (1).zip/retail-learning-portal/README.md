# Retail Learning & Development Portal

A full-stack starter website for a Retail Sales Officer Learning Management System.

## Technology
- Frontend: HTML5, CSS3, vanilla JavaScript
- Backend: Node.js + Express REST API
- Database: SQLite (local starter database)
- Authentication: bcrypt password hashing + JWT in an HTTP-only cookie
- Uploads: Multer (local `uploads/` directory)

## Requirements
- Node.js 18 or newer
- npm

## Run locally
1. Extract this ZIP file.
2. Open a terminal in the extracted `retail-learning-portal` folder.
3. Install dependencies:
   ```bash
   npm install
   ```
4. Copy `.env.example` to `.env` and replace `JWT_SECRET` with a long random secret.
5. Start the website:
   ```bash
   npm start
   ```
6. Open `http://localhost:3000`.

For automatic server restart during development:
```bash
npm run dev
```

## Demo logins
All demo accounts use the temporary password `ChangeMe123!`.

| Role | Email |
|---|---|
| Super Administrator | admin@retaildemo.local |
| Retail Sales Officer | rahul@retaildemo.local |
| Store Manager | priya@retaildemo.local |
| Trainer | arjun@retaildemo.local |

**Immediately change or remove demo accounts and passwords before deployment.**

## Included modules
Home dashboard, Admin employee management, Gallery, Digital Library upload, Scorecard, Quiz and attempt history, Test landing page, Achievement, Courses and course progress, Contact/support requests.

## API overview
- `POST /api/auth/login`, `POST /api/auth/logout`, `GET /api/auth/me`
- `GET /api/dashboard`
- `GET /api/courses`, `POST /api/courses`, `PATCH /api/courses/:id/progress`
- `GET /api/users`, `POST /api/users`, `PATCH /api/users/:id/deactivate`
- `POST /api/enrollments`
- `GET /api/resources`, `POST /api/resources`
- `POST /api/quiz/attempt`, `GET /api/quiz/history`
- `POST /api/support`, `GET /api/support`, `PATCH /api/support/:id/status`
- `GET /api/admin/analytics`

## Before production deployment
This is a starter application, not a security-audited enterprise LMS. Before using real employee information:
- Use HTTPS and set a strong secret in environment variables.
- Replace SQLite with managed PostgreSQL/MySQL if required by scale and IT standards.
- Add password reset, MFA/SSO, account lockout, CSRF protections, rate limiting and security headers.
- Review role permissions and enforce store/region-level data scopes on every API.
- Add server-side validation, audit review, backups, retention policies and monitoring.
- Store uploaded files in private object storage; scan uploads and serve them through authorised routes.
- Build complete admin workflows for editing employees, assigning courses, assessment question banks, timed tests, certificate PDFs, notifications and reporting.
- Validate accessibility, browser compatibility and data privacy requirements with your IT/security team.

## Data
A local SQLite file named `retail_lms.db` is created automatically on first run. It contains sample users and courses. Do not use the sample records as real employee data.
