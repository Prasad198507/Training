const express = require("express");
const path = require("path");
const fs = require("fs");
const cookieParser = require("cookie-parser");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const multer = require("multer");
const Database = require("better-sqlite3");

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || "development-only-change-this-secret";
const db = new Database(path.join(__dirname, "retail_lms.db"));
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

app.use(express.json({ limit: "2mb" }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, "public")));
app.use("/uploads", express.static(path.join(__dirname, "uploads")));

db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, employee_id TEXT UNIQUE NOT NULL,
 email TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, role TEXT NOT NULL,
 designation TEXT DEFAULT 'Retail Sales Officer', store TEXT DEFAULT '', region TEXT DEFAULT '',
 active INTEGER DEFAULT 1, created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS courses (
 id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, category TEXT NOT NULL,
 description TEXT DEFAULT '', level TEXT DEFAULT 'Beginner', duration_minutes INTEGER DEFAULT 30,
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS enrollments (
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, course_id INTEGER NOT NULL,
 progress INTEGER DEFAULT 0, completed_at TEXT, UNIQUE(user_id,course_id),
 FOREIGN KEY(user_id) REFERENCES users(id), FOREIGN KEY(course_id) REFERENCES courses(id)
);
CREATE TABLE IF NOT EXISTS attempts (
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, quiz_name TEXT NOT NULL,
 score INTEGER NOT NULL, total INTEGER NOT NULL, passed INTEGER NOT NULL,
 created_at TEXT DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(user_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS resources (
 id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, category TEXT NOT NULL,
 kind TEXT NOT NULL, file_path TEXT NOT NULL, uploaded_by INTEGER, created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS support_requests (
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, type TEXT NOT NULL,
 subject TEXT NOT NULL, message TEXT NOT NULL, status TEXT DEFAULT 'Open',
 created_at TEXT DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(user_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS audit_logs (
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, action TEXT NOT NULL,
 detail TEXT DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
`);

const seedCourses = [
 ["Watch Technology Fundamentals","Product Knowledge","Understand watch components, movements and customer-friendly explanations.","Beginner",35],
 ["Product Features & Benefits","Product Knowledge","Translate product specifications into meaningful customer benefits.","Beginner",30],
 ["Materials, Construction & Care","Product Knowledge","Learn about cases, straps, dials, materials and product care.","Intermediate",40],
 ["Store Opening & Closing SOP","Retail Operations","Follow consistent daily store routines and operational standards.","Beginner",25],
 ["Inventory & Stock Handling","Retail Operations","Understand stock accuracy, handling practices and replenishment.","Intermediate",35],
 ["Customer Greeting & Need Discovery","Sales Excellence","Build rapport and identify customer needs through effective questions.","Beginner",30],
 ["Objection Handling & Closing","Sales Excellence","Respond to concerns and guide customers towards confident decisions.","Advanced",45],
 ["Customer Complaint Handling","Customer Experience","Use empathy and service recovery to improve customer experience.","Intermediate",35],
 ["Communication & Teamwork","Professional Development","Strengthen workplace communication, collaboration and problem-solving.","Beginner",30]
];
if (db.prepare("SELECT COUNT(*) n FROM courses").get().n === 0) {
 const ins = db.prepare("INSERT INTO courses(title,category,description,level,duration_minutes) VALUES(?,?,?,?,?)");
 seedCourses.forEach(c=>ins.run(...c));
}
if (db.prepare("SELECT COUNT(*) n FROM users").get().n === 0) {
 const hash = bcrypt.hashSync("ChangeMe123!", 12);
 const ins = db.prepare(`INSERT INTO users(name,employee_id,email,password_hash,role,designation,store,region)
 VALUES(?,?,?,?,?,?,?,?)`);
 [
  ["Portal Administrator","ADMIN001","admin@retaildemo.local",hash,"Super Administrator","Training Manager","Head Office","National"],
  ["Rahul Sharma","RS1024","rahul@retaildemo.local",hash,"Retail Sales Officer","Retail Sales Officer","Bengaluru Central","South"],
  ["Priya Nair","PN1025","priya@retaildemo.local",hash,"Store Manager","Store Manager","Mysuru","South"],
  ["Arjun Mehta","AM1026","arjun@retaildemo.local",hash,"Trainer","Trainer","Pune","West"]
 ].forEach(u=>ins.run(...u));
 const courseIds=db.prepare("SELECT id FROM courses").all();
 const users=db.prepare("SELECT id FROM users").all();
 const enroll=db.prepare("INSERT OR IGNORE INTO enrollments(user_id,course_id,progress) VALUES(?,?,?)");
 users.forEach(u=>courseIds.forEach((c,i)=>enroll.run(u.id,c.id,i%3===0?100:(i%2===0?35:0))));
}

const ROLES = ["Super Administrator","Training Manager","Store Manager","Trainer","Retail Sales Officer"];
function auth(req,res,next){
 const token=req.cookies.lms_token;
 if(!token) return res.status(401).json({error:"Please sign in."});
 try { req.user=jwt.verify(token,JWT_SECRET); next(); }
 catch { res.clearCookie("lms_token"); return res.status(401).json({error:"Session expired. Sign in again."}); }
}
function allow(...roles){return (req,res,next)=>roles.includes(req.user.role)?next():res.status(403).json({error:"You do not have permission for this action."});}
function log(userId,action,detail=""){db.prepare("INSERT INTO audit_logs(user_id,action,detail) VALUES(?,?,?)").run(userId,action,detail);}
const adminRoles=["Super Administrator","Training Manager"];
const storage=multer.diskStorage({
 destination:(req,file,cb)=>cb(null,path.join(__dirname,"uploads")),
 filename:(req,file,cb)=>cb(null,Date.now()+"-"+file.originalname.replace(/[^a-zA-Z0-9._-]/g,"_"))
});
const upload=multer({storage,limits:{fileSize:25*1024*1024},fileFilter:(req,file,cb)=>{
 const ok=/\.(pdf|ppt|pptx|doc|docx|jpg|jpeg|png|webp|mp4|mov)$/i.test(file.originalname);
 cb(ok?null:new Error("File type not allowed."),ok);
}});

app.post("/api/auth/login",(req,res)=>{
 const {email,password}=req.body||{};
 const user=db.prepare("SELECT * FROM users WHERE email=? AND active=1").get(String(email||"").trim().toLowerCase());
 if(!user||!bcrypt.compareSync(String(password||""),user.password_hash)) return res.status(401).json({error:"Invalid email or password."});
 const token=jwt.sign({id:user.id,name:user.name,employeeId:user.employee_id,role:user.role},JWT_SECRET,{expiresIn:"8h"});
 res.cookie("lms_token",token,{httpOnly:true,sameSite:"lax",secure:process.env.NODE_ENV==="production",maxAge:8*60*60*1000});
 log(user.id,"LOGIN");
 res.json({user:{id:user.id,name:user.name,employeeId:user.employee_id,role:user.role,designation:user.designation,store:user.store,region:user.region}});
});
app.post("/api/auth/logout",(req,res)=>{res.clearCookie("lms_token");res.json({ok:true});});
app.get("/api/auth/me",auth,(req,res)=>{
 const u=db.prepare("SELECT id,name,employee_id AS employeeId,email,role,designation,store,region FROM users WHERE id=?").get(req.user.id);
 res.json({user:u});
});

app.get("/api/dashboard",auth,(req,res)=>{
 const isAdmin=adminRoles.includes(req.user.role);
 const uid=isAdmin?null:req.user.id;
 const total=db.prepare("SELECT COUNT(*) n FROM courses").get().n;
 const enrolled=uid===null?db.prepare("SELECT COUNT(*) n FROM enrollments").get().n:db.prepare("SELECT COUNT(*) n FROM enrollments WHERE user_id=?").get(uid).n;
 const completed=uid===null?db.prepare("SELECT COUNT(*) n FROM enrollments WHERE progress=100").get().n:db.prepare("SELECT COUNT(*) n FROM enrollments WHERE user_id=? AND progress=100").get(uid).n;
 const avg=uid===null?db.prepare("SELECT COALESCE(AVG(score),0) n FROM attempts").get().n:db.prepare("SELECT COALESCE(AVG(score),0) n FROM attempts WHERE user_id=?").get(uid).n;
 const employees=db.prepare("SELECT COUNT(*) n FROM users WHERE active=1").get().n;
 res.json({totalCourses:total,enrolledCourses:enrolled,completedCourses:completed,pendingCourses:Math.max(enrolled-completed,0),completionRate:enrolled?Math.round(completed/enrolled*100):0,averageQuizScore:Math.round(avg),employees,learningHours:0,certificates:completed});
});

app.get("/api/courses",auth,(req,res)=>{
 const rows=db.prepare(`SELECT c.*, COALESCE(e.progress,0) progress FROM courses c
 LEFT JOIN enrollments e ON e.course_id=c.id AND e.user_id=? ORDER BY c.category,c.title`).all(req.user.id);
 res.json(rows);
});
app.post("/api/courses",auth,allow(...adminRoles),(req,res)=>{
 const {title,category,description="",level="Beginner",duration_minutes=30}=req.body||{};
 if(!title||!category)return res.status(400).json({error:"Title and category are required."});
 const r=db.prepare("INSERT INTO courses(title,category,description,level,duration_minutes) VALUES(?,?,?,?,?)").run(title,category,description,level,Number(duration_minutes)||30);
 log(req.user.id,"COURSE_CREATED",title);res.status(201).json({id:r.lastInsertRowid});
});
app.patch("/api/courses/:id/progress",auth,(req,res)=>{
 const id=Number(req.params.id),progress=Math.max(0,Math.min(100,Number(req.body.progress)||0));
 if(!db.prepare("SELECT id FROM courses WHERE id=?").get(id))return res.status(404).json({error:"Course not found."});
 db.prepare("INSERT INTO enrollments(user_id,course_id,progress,completed_at) VALUES(?,?,?,?) ON CONFLICT(user_id,course_id) DO UPDATE SET progress=excluded.progress,completed_at=excluded.completed_at")
 .run(req.user.id,id,progress,progress===100?new Date().toISOString():null);
 log(req.user.id,"COURSE_PROGRESS",`${id}:${progress}`);res.json({ok:true,progress});
});

app.get("/api/users",auth,allow(...adminRoles,"Store Manager","Trainer"),(req,res)=>{
 let rows=db.prepare("SELECT id,name,employee_id AS employeeId,email,role,designation,store,region,active FROM users ORDER BY name").all();
 if(req.user.role==="Store Manager") rows=rows.filter(u=>u.store===db.prepare("SELECT store FROM users WHERE id=?").get(req.user.id).store);
 res.json(rows);
});
app.post("/api/users",auth,allow(...adminRoles),(req,res)=>{
 const {name,employeeId,email,role="Retail Sales Officer",designation="Retail Sales Officer",store="",region="",password="ChangeMe123!"}=req.body||{};
 if(!name||!employeeId||!email||!ROLES.includes(role))return res.status(400).json({error:"Name, employee ID, email and valid role are required."});
 try{
  const r=db.prepare("INSERT INTO users(name,employee_id,email,password_hash,role,designation,store,region) VALUES(?,?,?,?,?,?,?,?)")
   .run(name,employeeId,email.toLowerCase(),bcrypt.hashSync(password,12),role,designation,store,region);
  log(req.user.id,"USER_CREATED",employeeId);res.status(201).json({id:r.lastInsertRowid});
 }catch(e){res.status(409).json({error:"Email or employee ID already exists."});}
});
app.patch("/api/users/:id/deactivate",auth,allow(...adminRoles),(req,res)=>{
 db.prepare("UPDATE users SET active=0 WHERE id=?").run(Number(req.params.id));log(req.user.id,"USER_DEACTIVATED",req.params.id);res.json({ok:true});
});
app.post("/api/enrollments",auth,allow(...adminRoles),(req,res)=>{
 const {userId,courseId}=req.body||{};
 try{db.prepare("INSERT OR IGNORE INTO enrollments(user_id,course_id) VALUES(?,?)").run(Number(userId),Number(courseId));res.json({ok:true});}
 catch(e){res.status(400).json({error:"Invalid employee or course."});}
});

app.get("/api/resources",auth,(req,res)=>res.json(db.prepare("SELECT id,title,category,kind,file_path AS filePath,created_at AS createdAt FROM resources ORDER BY created_at DESC").all()));
app.post("/api/resources",auth,allow(...adminRoles,"Trainer"),upload.single("file"),(req,res)=>{
 if(!req.file)return res.status(400).json({error:"Choose a file to upload."});
 const {title,category="General",kind="Document"}=req.body;
 const filePath="/uploads/"+req.file.filename;
 const r=db.prepare("INSERT INTO resources(title,category,kind,file_path,uploaded_by) VALUES(?,?,?,?,?)").run(title||req.file.originalname,category,kind,filePath,req.user.id);
 log(req.user.id,"RESOURCE_UPLOADED",title||req.file.originalname);res.status(201).json({id:r.lastInsertRowid,filePath});
});

app.post("/api/quiz/attempt",(req,res,next)=>auth(req,res,next),(req,res)=>{
 const {quizName="Knowledge Quiz",score,total}=req.body||{};
 if(!Number.isFinite(Number(score))||!Number.isFinite(Number(total))||Number(total)<=0)return res.status(400).json({error:"Valid score and total are required."});
 const pct=Math.round(Number(score)/Number(total)*100),passed=pct>=70?1:0;
 const r=db.prepare("INSERT INTO attempts(user_id,quiz_name,score,total,passed) VALUES(?,?,?,?,?)").run(req.user.id,quizName,pct,100,passed);
 log(req.user.id,"QUIZ_ATTEMPT",`${quizName}:${pct}`);res.status(201).json({id:r.lastInsertRowid,score:pct,passed:!!passed});
});
app.get("/api/quiz/history",auth,(req,res)=>res.json(db.prepare("SELECT quiz_name AS quizName,score,total,passed,created_at AS date FROM attempts WHERE user_id=? ORDER BY id DESC LIMIT 30").all(req.user.id)));

app.post("/api/support",auth,(req,res)=>{
 const {type="Training query",subject,message}=req.body||{};
 if(!subject||!message)return res.status(400).json({error:"Subject and message are required."});
 const r=db.prepare("INSERT INTO support_requests(user_id,type,subject,message) VALUES(?,?,?,?)").run(req.user.id,type,subject,message);
 log(req.user.id,"SUPPORT_REQUEST",subject);res.status(201).json({id:r.lastInsertRowid,status:"Open"});
});
app.get("/api/support",auth,(req,res)=>{
 const sql=adminRoles.includes(req.user.role)
 ? `SELECT s.*,u.name employee FROM support_requests s JOIN users u ON u.id=s.user_id ORDER BY s.id DESC`
 : `SELECT * FROM support_requests WHERE user_id=? ORDER BY id DESC`;
 res.json(adminRoles.includes(req.user.role)?db.prepare(sql).all():db.prepare(sql).all(req.user.id));
});
app.patch("/api/support/:id/status",auth,allow(...adminRoles),(req,res)=>{
 const status=["Open","In Progress","Resolved"].includes(req.body.status)?req.body.status:"Open";
 db.prepare("UPDATE support_requests SET status=? WHERE id=?").run(status,Number(req.params.id));res.json({ok:true});
});
app.get("/api/admin/analytics",auth,allow(...adminRoles),(req,res)=>{
 const byCategory=db.prepare(`SELECT c.category,ROUND(AVG(e.progress)) progress,COUNT(e.id) assignments
 FROM courses c LEFT JOIN enrollments e ON e.course_id=c.id GROUP BY c.category`).all();
 const top=db.prepare(`SELECT u.name,u.employee_id employeeId,ROUND(AVG(a.score)) averageScore,COUNT(a.id) attempts
 FROM users u LEFT JOIN attempts a ON a.user_id=u.id GROUP BY u.id ORDER BY averageScore DESC LIMIT 10`).all();
 res.json({byCategory,top});
});

app.get("/api/health",(req,res)=>res.json({ok:true,service:"Retail L&D Portal"}));
app.use((err,req,res,next)=>{console.error(err);res.status(400).json({error:err.message||"Request failed."});});
app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
app.listen(PORT,()=>console.log(`Retail L&D Portal running at http://localhost:${PORT}`));
